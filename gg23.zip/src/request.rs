use minicbor::{Decode, Encode};

use crate::{
    merkle::types::{
        BlocksBundles, ChainMerkleState, ChainState, SerializableMerkleInsertReport, SubtreeRoots,
    },
    orchard::types::{OrchardProofParams, OrchardVerifyProofParams},
    sapling::types::{
        SaplingOutputBytes, SaplingOutputVerificationBytes, SaplingSpendBytes,
        SaplingSpendVerificationBytes,
    },
};

#[derive(Debug, Encode, Decode)]
#[cbor(tag(23035))]
#[cbor(array)]
pub enum ZKRequest {
    #[n(0)]
    MerkleCreateContext(#[n(0)] ChainMerkleState),
    #[n(1)]
    /// (Sapling,Orchard)
    MerkleUpdateSubtree(#[n(0)] u32, #[n(1)] u8, #[n(2)] SubtreeRoots),
    #[n(2)]
    MerkleInsertChainState(#[n(0)] u32, #[n(1)] ChainState),
    #[n(3)]
    MerkleUpdateState(#[n(0)] u32, #[n(1)] BlocksBundles),
    #[n(4)]
    MerkleMergeState(#[n(0)] u32, #[n(1)] SerializableMerkleInsertReport),
    #[n(5)]
    MerkleCloseContext(#[n(0)] u32),
    #[n(6)]
    SaplingHasSpendParams(),
    #[n(7)]
    SaplingHasOutputParams(),

    #[n(8)]
    SaplingSetupSpendParams(
        #[n(0)]
        #[cbor(with = "minicbor::bytes")]
        Vec<u8>,
    ),
    #[n(9)]
    SaplingSetupOutputParams(
        #[n(0)]
        #[cbor(with = "minicbor::bytes")]
        Vec<u8>,
    ),
    #[n(10)]
    SaplingCreateSpendProof(#[n(0)] SaplingSpendBytes),

    #[n(11)]
    SaplingCreateOutputProof(#[n(0)] SaplingOutputBytes),
    #[n(12)]
    SaplingVerifySpendProof(#[n(0)] SaplingSpendVerificationBytes),
    #[n(13)]
    SaplingVerifyOutputProof(#[n(0)] SaplingOutputVerificationBytes),

    #[n(14)]
    OrchardCreateActionProof(#[n(0)] OrchardProofParams),

    #[n(15)]
    OrchardVerifyActionProof(#[n(0)] OrchardVerifyProofParams),

    #[n(16)]
    SaplingClearSpendParams(),
    #[n(17)]
    SaplingClearOutputParams(),
    #[n(18)]
    SaplingClearOrchardProvingKey(),
    #[n(19)]
    Version(),

    #[n(20)]
    MerkleGetContext(#[n(0)] u32),
}
