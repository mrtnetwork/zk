use crate::{
    error::{Error, ErrorWithMsg, IError},
    sapling::{
        circuit::{Output, Spend, ValueCommitmentOpening},
        types::{
            SaplingOutputBytes, SaplingOutputVerification, SaplingOutputVerificationBytes,
            SaplingSpendBytes, SaplingSpendVerification, SaplingSpendVerificationBytes,
            MAX_AUTH_PATH, MAX_OUTPUT_VERIFY_INPUTS, MAX_SPEND_VERIFY_INPUTS,
        },
    },
};
use bls12_381::Scalar;
use ff::PrimeField;
use group::GroupEncoding;
use jubjub::Fr;

use std::convert::TryInto;

pub struct ZKSaplingUtils;
impl ZKSaplingUtils {
    pub fn fr_from_bytes(bytes: [u8; 32]) -> IError<Fr> {
        Fr::from_repr(bytes).into_option().ok_or(ErrorWithMsg {
            code: Error::InvalidKeyEncoding,
            msg: "Invalid fr bytes.".to_string(),
        })
    }

    pub fn scalar_from_bytes(bytes: [u8; 32]) -> IError<Scalar> {
        Scalar::from_repr(bytes).into_option().ok_or(ErrorWithMsg {
            code: Error::InvalidKeyEncoding,
            msg: "Invalid scalar bytes.".to_string(),
        })
    }

    pub fn extended_from_bytes(bytes: [u8; 32]) -> IError<jubjub::ExtendedPoint> {
        jubjub::ExtendedPoint::from_bytes(&bytes)
            .into_option()
            .ok_or(ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid jubjub point bytes.".to_string(),
            })
    }

    pub fn parse_sapling_output_proof(bytes: SaplingOutputBytes) -> IError<Output> {
        Ok(Output {
            value_commitment_opening: Some(ValueCommitmentOpening {
                value: bytes.value,
                randomness: ZKSaplingUtils::fr_from_bytes(bytes.randomness.into())?,
            }),
            recipient_address_diversify_hash: Some(ZKSaplingUtils::extended_from_bytes(
                bytes.recipient_address_diversify_hash.into(),
            )?),
            recipient_address_pk_d: Some(ZKSaplingUtils::extended_from_bytes(
                bytes.recipient_address_pk_d.into(),
            )?),
            esk: Some(ZKSaplingUtils::fr_from_bytes(bytes.esk.into())?),
            commitment_randomness: Some(ZKSaplingUtils::fr_from_bytes(
                bytes.commitment_randomness.into(),
            )?),
        })
    }

    pub fn parse_sapling_spend_proof(bytes: SaplingSpendBytes) -> IError<Spend> {
        let mut auth_path = Vec::with_capacity(MAX_AUTH_PATH);

        for i in 0..MAX_AUTH_PATH {
            let scalar = ZKSaplingUtils::scalar_from_bytes(bytes.auth_path[i].into())?;
            let flag = bytes.auth_path_pos[i];
            auth_path.push(Some((scalar, flag)));
        }

        Ok(Spend {
            value_commitment_opening: Some(ValueCommitmentOpening {
                value: bytes.value as u64,
                randomness: ZKSaplingUtils::fr_from_bytes(bytes.randomness.into())?,
            }),
            ak: Some(ZKSaplingUtils::extended_from_bytes(bytes.ak.into())?),
            nsk: Some(ZKSaplingUtils::fr_from_bytes(bytes.nsk.into())?),
            payment_address_diversify_hash: Some(ZKSaplingUtils::extended_from_bytes(
                bytes.payment_address_diversify_hash.into(),
            )?),
            anchor: Some(ZKSaplingUtils::scalar_from_bytes(bytes.anchor.into())?),
            ar: Some(ZKSaplingUtils::fr_from_bytes(bytes.ar.into())?),
            auth_path,
            commitment_randomness: Some(ZKSaplingUtils::fr_from_bytes(
                bytes.commitment_randomness.into(),
            )?),
        })
    }

    pub fn parse_sapling_spend_verification(
        bytes: SaplingSpendVerificationBytes,
    ) -> IError<SaplingSpendVerification> {
        let mut vec_inputs = Vec::with_capacity(MAX_SPEND_VERIFY_INPUTS);
        for i in 0..MAX_SPEND_VERIFY_INPUTS {
            let scalar = ZKSaplingUtils::scalar_from_bytes(bytes.public_inputs[i].into())?;
            vec_inputs.push(scalar);
        }

        // Convert Vec<T> → [T; N] using TryInto
        let public_inputs: [Scalar; MAX_SPEND_VERIFY_INPUTS] =
            vec_inputs.try_into().map_err(|_| ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid prams length".to_string(),
            })?;

        Ok(SaplingSpendVerification {
            proof: bytes.proof.into(),
            public_inputs,
        })
    }

    pub fn parse_sapling_output_verification(
        bytes: SaplingOutputVerificationBytes,
    ) -> IError<SaplingOutputVerification> {
        let mut vec_inputs = Vec::with_capacity(MAX_OUTPUT_VERIFY_INPUTS);
        for i in 0..MAX_OUTPUT_VERIFY_INPUTS {
            let scalar = ZKSaplingUtils::scalar_from_bytes(bytes.public_inputs[i].into())?;
            vec_inputs.push(scalar);
        }

        let public_inputs: [Scalar; MAX_OUTPUT_VERIFY_INPUTS] =
            vec_inputs.try_into().map_err(|_| ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid prams length".to_string(),
            })?;

        Ok(SaplingOutputVerification {
            proof: bytes.proof.into(),
            public_inputs,
        })
    }
}
