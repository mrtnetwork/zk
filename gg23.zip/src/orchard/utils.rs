use std::sync::Arc;

use ff::PrimeField;
use halo2_proofs::{
    plonk::{self, SingleVerifier},
    transcript::{Blake2bRead, Blake2bWrite},
};
use minicbor::bytes::ByteArray;
use orchard::{
    builder::SpendInfo,
    circuit::Circuit,
    keys::FullViewingKey,
    note::{RandomSeed, Rho},
    tree::{MerkleHashOrchard, MerklePath},
    value::{NoteValue, ValueCommitTrapdoor},
    Address, Note,
};
use pasta_curves::{pallas, vesta};
use rand_core::OsRng;

use crate::{
    error::{Error, ErrorWithMsg, IError},
    orchard::types::{OrchardProofParams, OrchardProof, OrchardVerifyProofParams, OrchardProofInputs},
};

pub struct ProvingKey {
    params: halo2_proofs::poly::commitment::Params<vesta::Affine>,
    pk: plonk::ProvingKey<vesta::Affine>,
}

impl ProvingKey {
    /// Builds the proving key.
    pub fn build() -> Self {
        let params = halo2_proofs::poly::commitment::Params::new(11);
        let circuit: Circuit = Default::default();

        let vk = plonk::keygen_vk(&params, &circuit).unwrap();
        let pk = plonk::keygen_pk(&params, vk, &circuit).unwrap();

        ProvingKey { params, pk }
    }
}

pub struct ZKOrchardUtils;

impl ZKOrchardUtils {
    pub fn fvk_from_bytes(bytes: [u8; 96]) -> IError<FullViewingKey> {
        FullViewingKey::from_bytes(&bytes).ok_or(ErrorWithMsg {
            code: Error::InvalidKeyEncoding,
            msg: "Invalid fvk bytes".to_string(),
        })
    }

    pub fn recipient_from_bytes(bytes: [u8; 43]) -> IError<Address> {
        Address::from_raw_address_bytes(&bytes)
            .into_option()
            .ok_or(ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid receipt address.".to_string(),
            })
    }

    pub fn rho_from_bytes(bytes: [u8; 32]) -> IError<Rho> {
        Rho::from_bytes(&bytes).into_option().ok_or(ErrorWithMsg {
            code: Error::InvalidKeyEncoding,
            msg: "Invalid RHO bytes.".to_string(),
        })
    }

    pub fn value_from_raw(value: u64) -> NoteValue {
        NoteValue::from_raw(value)
    }

    pub fn rseed_from_bytes(bytes: [u8; 32], rho: &Rho) -> IError<RandomSeed> {
        RandomSeed::from_bytes(bytes, rho)
            .into_option()
            .ok_or(ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid RSeed bytes.".to_string(),
            })
    }

    pub fn auth_path_from_bytes(bytes: [ByteArray<32>; 32]) -> IError<[MerkleHashOrchard; 32]> {
        bytes
            .map(|b| {
                MerkleHashOrchard::from_bytes(&b)
                    .into_option()
                    .ok_or(ErrorWithMsg {
                        code: Error::InvalidKeyEncoding,
                        msg: "Invalid orchard merkle hash.".to_string(),
                    })
            })
            .into_iter()
            .collect::<Result<Vec<_>, _>>()?
            .try_into()
            .map_err(|_| ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid orchard merkle hash.".to_string(),
            })
    }

    pub fn merkle_path_from_bytes(bytes: [ByteArray<32>; 32], position: u32) -> IError<MerklePath> {
        let auth_path = ZKOrchardUtils::auth_path_from_bytes(bytes)?;
        Ok(MerklePath::from_parts(position, auth_path))
    }

    pub fn vesta_scalar_from_bytes(bytes: ByteArray<32>) -> IError<vesta::Scalar> {
        vesta::Scalar::from_repr(bytes.into())
            .into_option()
            .ok_or(ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid vesta scalar bytes.".to_string(),
            })
    }

    pub fn pallas_scalar_from_bytes(bytes: [u8; 32]) -> IError<pallas::Scalar> {
        pallas::Scalar::from_repr(bytes)
            .into_option()
            .ok_or(ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid pallas scalar bytes.".to_string(),
            })
    }

    pub fn instances_from_bytes(bytes: [ByteArray<32>; 9]) -> IError<[vesta::Scalar; 9]> {
        bytes
            .map(ZKOrchardUtils::vesta_scalar_from_bytes)
            .into_iter()
            .collect::<Result<Vec<_>, _>>()?
            .try_into()
            .map_err(|_| ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid vesta scalar bytes.".to_string(),
            })
    }

    pub fn build_circuit(
        params: &OrchardProofInputs,
    ) -> IError<(Circuit, [[vesta::Scalar; 9]; 1])> {
        let fvk = ZKOrchardUtils::fvk_from_bytes(params.fvk.into())?;
        let recipient = ZKOrchardUtils::recipient_from_bytes(params.recipient.into())?;
        let value = ZKOrchardUtils::value_from_raw(params.value);
        let rho = ZKOrchardUtils::rho_from_bytes(params.rho.into())?;
        let rseed = ZKOrchardUtils::rseed_from_bytes(params.rseed.into(), &rho)?;
        let note = Note::from_parts(recipient, value, rho, rseed)
            .into_option()
            .ok_or(ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid note.".to_string(),
            })?;

        let merkle_path =
            ZKOrchardUtils::merkle_path_from_bytes(params.auth_path.into(), params.position)?;

        let out_recipient = ZKOrchardUtils::recipient_from_bytes(params.out_recipient.into())?;
        let out_value = ZKOrchardUtils::value_from_raw(params.out_value);
        let out_rho = ZKOrchardUtils::rho_from_bytes(params.out_rho.into())?;
        let out_rseed = ZKOrchardUtils::rseed_from_bytes(params.out_rseed.into(), &out_rho)?;
        let output_note = Note::from_parts(out_recipient, out_value, out_rho, out_rseed)
            .into_option()
            .ok_or(ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid note.".to_string(),
            })?;

        let alpha = ZKOrchardUtils::pallas_scalar_from_bytes(params.alpha.into())?;
        let rcv = ValueCommitTrapdoor::from_bytes(params.rcv.into())
            .into_option()
            .ok_or(ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid ValueCommitTrapdoor.".to_string(),
            })?;

        let spend_info = SpendInfo::new(fvk, note, merkle_path).ok_or(ErrorWithMsg {
            code: Error::InvalidKeyEncoding,
            msg: "Invalid spend info.".to_string(),
        })?;

        let instances = ZKOrchardUtils::instances_from_bytes(params.instances.into())?;

        let circuit = Circuit::from_action_context(spend_info, output_note, alpha, rcv).ok_or(
            ErrorWithMsg {
                code: Error::InvalidKeyEncoding,
                msg: "Invalid circuit.".to_string(),
            },
        )?;

        Ok((circuit, [instances]))
    }
    pub fn create_orchard_proof(
        pk: Arc<ProvingKey>,
        circuit_bytes: OrchardProofParams,
    ) -> IError<Vec<u8>> {
        // let (circuits, instances_arr) = parse_orchard_spends(payload)?;

        let mut circuits = Vec::with_capacity(circuit_bytes.circuits.len());
        let mut instances = Vec::with_capacity(circuit_bytes.circuits.len());

        for spend in &circuit_bytes.circuits {
            let (circuit, instance) = ZKOrchardUtils::build_circuit(spend)?;
            circuits.push(circuit);
            instances.push(instance);
        }

        let mut transcript = Blake2bWrite::<_, vesta::Affine, _>::init(vec![]);

        // Pre-allocate storage for instance rows
        let mut instance_rows: Vec<[&[vesta::Scalar]; 1]> = Vec::with_capacity(instances.len());

        for inst in &instances {
            // inst: [[Scalar; 9]; 1]
            let row: &[vesta::Scalar] = &inst[0];

            // Store a 1-element array per circuit
            instance_rows.push([row]);
        }

        // Now build &[&[&[Scalar]]] from stable storage
        let instance_refs: Vec<&[&[vesta::Scalar]]> =
            instance_rows.iter().map(|r| &r[..]).collect();

        let instances: &[&[&[vesta::Scalar]]] = &instance_refs;

        let rng = OsRng;

        plonk::create_proof(
            &pk.params,
            &pk.pk,
            &circuits,
            instances,
            rng,
            &mut transcript,
        )
        .map_err(|e| ErrorWithMsg {
            code: Error::OrchardProofCreationFailed,
            msg: e.to_string(),
        })?;

        Ok(transcript.finalize())
    }
    pub fn parse_proof_bytes(p: OrchardVerifyProofParams) -> IError<OrchardProof> {
        let proof = p.proof;

        let instances: Vec<[[vesta::Scalar; 9]; 1]> = p
            .instances
            .into_iter()
            .map(|row| -> Result<[[vesta::Scalar; 9]; 1], ErrorWithMsg> {
                let mut out = [vesta::Scalar::default(); 9];

                for (i, b) in row.into_iter().enumerate() {
                    out[i] = ZKOrchardUtils::vesta_scalar_from_bytes(b.into())?;
                }

                Ok([out]) // <-- THIS is the missing layer
            })
            .collect::<Result<Vec<_>, _>>()?;

        Ok(OrchardProof { proof, instances })
    }
    pub fn verify_orchard_proof(pk: Arc<ProvingKey>, payload: OrchardVerifyProofParams) -> IError<bool> {
        let proof = ZKOrchardUtils::parse_proof_bytes(payload)?;
        let vk = pk.pk.get_vk();
        let params = &pk.params;
        let strategy = SingleVerifier::new(&params);

        let mut transcript = Blake2bRead::init(&proof.proof[..]);

        // 2. Convert owned instances → borrowed refs
        let instances_refs: Vec<&[&[vesta::Scalar]]> = proof
            .instances
            .iter()
            .map(|outer| {
                let inner: Vec<&[vesta::Scalar]> = outer.iter().map(|v| v.as_slice()).collect();
                let leaked: &mut [&[vesta::Scalar]] = inner.leak();
                let immut: &[&[vesta::Scalar]] = leaked;
                immut
            })
            .collect();

        // 3. Final shape required by PLONK
        let instances: &[&[&[vesta::Scalar]]] = &instances_refs;
        let result = plonk::verify_proof(params, vk, strategy, instances, &mut transcript);
        Ok(result.is_ok())
    }
}
