#[repr(u32)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum Error {
    // General
    InvalidLength = 1,
    InvalidPointEncoding = 2,

    SaplingInvalidParameters = 3,
    UnexpectedError = 4,
    SaplingSpendNotInitialized = 5,
    SaplingOutputNotInitialized = 6,
    UnknowRequestId = 7,
    // Sapling-specific
    SaplingInvalidValue = 10,
    SaplingInvalidRandomness = 11,
    SaplingInvalidAuthPath = 12,
    SaplingInvalidAnchor = 13,
    SaplingInvalidProof = 14,

    /// orchard
    OrchardInvalidFvk = 20,
    OrchardInvalidAddress = 21,
    OrchardInvalidRho = 22,
    OrchardInvalidRseed = 23,
    OrchardInvalidAuthPath = 24,
    OrchardInvalidScalar = 25,
    OrchardInvalidNote = 26,
    OrchardInvalidCommitment = 27,
    OrchardInvalidSpend = 28,
    OrchardInvalidCircuit = 29,
    OrchardProofCreationFailed = 30,
    InvalidKeyEncoding = 31,
    InternalError = 32,
    InvalidRequest = 33,
}
pub struct ErrorWithMsg {
    pub code: Error,
    pub msg: alloc::string::String,
}
impl ErrorWithMsg {
    pub fn invalid_key_encoding(msg: alloc::string::String) -> Self {
        ErrorWithMsg {
            code: Error::InvalidKeyEncoding,
            msg: msg,
        }
    }
}
pub type IError<T> = Result<T, ErrorWithMsg>;
