use crate::{
    error::{Error, ErrorWithMsg, IError},
    sapling::node::SaplingNode,
};

use incrementalmerkletree::{
    frontier::NonEmptyFrontier, Address, Level, Marking, Position, Retention,
};

use minicbor::{bytes::ByteArray, Decode, Encode};
use orchard::tree::MerkleHashOrchard;
use shardtree::{
    store::{memory::MemoryShardStore, Checkpoint, ShardStore},
    LocatedPrunableTree, LocatedTree, Node, PrunableTree, RetentionFlags, ShardTree, Tree,
};
use std::sync::Arc;

pub const NOTE_COMMITMENT_TREE_DEPTH: u8 = 32;
pub const SHARD_HEIGHT: u8 = NOTE_COMMITMENT_TREE_DEPTH / 2;
pub const SHARD_HEIGHT_LEVEL: Level = Level::new(SHARD_HEIGHT);
pub const MAX_CHECKPOINTS: usize = 100;
pub type OrchardShardStore = MemoryShardStore<orchard::tree::MerkleHashOrchard, u32>;
pub type SaplingShardStore = MemoryShardStore<SaplingNode, u32>;

#[repr(u8)]
#[derive(Debug, Copy, Clone, PartialEq, Eq)]
pub enum ShieldProtocol {
    Sapling = 0,
    Orchard = 1,
}
impl TryFrom<u8> for ShieldProtocol {
    type Error = ErrorWithMsg;

    fn try_from(value: u8) -> IError<Self> {
        match value {
            1 => Ok(Self::Orchard),
            0 => Ok(Self::Sapling),
            _ => Err(ErrorWithMsg {
                code: Error::InvalidRequest,
                msg: "Invalid shield protocol.".to_string(),
            }),
        }
    }
}
pub trait IntoNode {
    fn try_into_node(self) -> IError<SaplingNode>;
    fn try_into_merkle_hash(self) -> IError<MerkleHashOrchard>;
}

impl IntoNode for ByteArray<32> {
    fn try_into_node(self) -> IError<SaplingNode> {
        SaplingNode::from_bytes(*self.as_ref()).map_err(|_| {
            ErrorWithMsg::invalid_key_encoding("Invalid sapling node bytes.".to_string())
        })
    }

    fn try_into_merkle_hash(self) -> IError<MerkleHashOrchard> {
        MerkleHashOrchard::from_bytes(self.as_ref())
            .into_option()
            .ok_or(ErrorWithMsg::invalid_key_encoding(
                "Invalid merkle hash orchard bytes.".to_string(),
            ))
    }
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23027))]
#[cbor(array)]
pub enum RetentionRepr {
    #[n(0)]
    Ephemeral,

    #[n(1)]
    Checkpoint {
        #[n(0)]
        id: u32,
        #[n(1)]
        marking: u8,
    },

    #[n(2)]
    Marked,

    #[n(3)]
    Reference,
}
impl RetentionRepr {
    pub fn dummy_ephemeral() -> Self {
        Self::Ephemeral
    }

    pub fn dummy_checkpoint() -> Self {
        Self::Checkpoint { id: 42, marking: 1 }
    }

    pub fn dummy_marked() -> Self {
        Self::Marked
    }

    pub fn dummy_reference() -> Self {
        Self::Reference
    }

    pub fn to_retention(&self) -> IError<Retention<u32>> {
        Ok(match self {
            RetentionRepr::Ephemeral => Retention::Ephemeral,
            RetentionRepr::Checkpoint { id, marking } => Retention::Checkpoint {
                id: *id,
                marking: match marking {
                    0 => Marking::Marked,
                    1 => Marking::Reference,
                    2 => Marking::None,
                    _ => {
                        return Err(ErrorWithMsg {
                            code: Error::InvalidRequest,
                            msg: "Invalid retention marking kind.".to_string(),
                        })
                    }
                },
            },
            RetentionRepr::Marked => Retention::Marked,
            RetentionRepr::Reference => Retention::Reference,
        })
    }
}
#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23032))]
#[cbor(array)]
pub struct BlockCommitment {
    #[n(0)]
    pub node: ByteArray<32>,
    #[n(1)]
    pub retention: RetentionRepr,
}

impl BlockCommitment {
    pub fn to_orchard_commitment(&self) -> IError<(MerkleHashOrchard, Retention<u32>)> {
        let node = self.node.try_into_merkle_hash()?;
        let retention = self.to_retention()?;
        Ok((node, retention))
    }

    pub fn to_sapling_commitment(&self) -> IError<(SaplingNode, Retention<u32>)> {
        let node = self.node.try_into_node()?;
        let retention = self.to_retention()?;
        Ok((node, retention))
    }

    pub fn to_retention(&self) -> IError<Retention<u32>> {
        self.retention.to_retention()
    }
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23046))]
#[cbor(array)]
pub struct ScannedProtocolBundles {
    #[n(0)]
    pub final_tree_size: u32,
    #[n(1)]
    pub commitment: Vec<BlockCommitment>,
}
pub type SaplingIter = std::vec::IntoIter<(SaplingNode, Retention<u32>)>;
pub type OrchardIter = std::vec::IntoIter<(MerkleHashOrchard, Retention<u32>)>;
impl ScannedProtocolBundles {
    pub fn into_sapling_iter(self) -> IError<impl Iterator<Item = (SaplingNode, Retention<u32>)>> {
        let v: IError<Vec<_>> = self
            .commitment
            .into_iter()
            .map(|c| c.to_sapling_commitment())
            .collect();

        Ok(v?.into_iter())
    }
    pub fn into_orchard_iter(self) -> IError<OrchardIter> {
        let v: IError<Vec<_>> = self
            .commitment
            .into_iter()
            .map(|c| c.to_orchard_commitment())
            .collect();

        Ok(v?.into_iter())
    }
    pub fn into_sapling_iter_all(bundles: Vec<ScannedProtocolBundles>) -> IError<SaplingIter> {
        let mut out = Vec::new();

        for b in bundles {
            let iter = b.into_sapling_iter()?;
            out.extend(iter);
        }

        Ok(out.into_iter())
    }
    pub fn into_orchard_iter_all(bundles: Vec<ScannedProtocolBundles>) -> IError<OrchardIter> {
        let mut out = Vec::new();

        for b in bundles {
            let iter = b.into_orchard_iter()?;
            out.extend(iter);
        }

        Ok(out.into_iter())
    }
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23028))]
#[cbor(array)]
pub enum SerializableNode {
    #[n(0)]
    Parent(
        #[n(0)] Option<ByteArray<32>>,
        #[n(1)] Box<SerializableNode>,
        #[n(2)] Box<SerializableNode>,
    ),
    #[n(1)]
    Leaf(#[n(0)] ByteArray<32>, #[n(1)] u8),
    #[n(2)]
    Nil,
}
impl<H> TryFrom<&Tree<Option<Arc<H>>, (H, RetentionFlags)>> for SerializableNode
where
    H: MerkleCodec + Clone,
{
    type Error = ErrorWithMsg;

    fn try_from(tree: &Tree<Option<Arc<H>>, (H, RetentionFlags)>) -> IError<Self> {
        match &**tree {
            Node::Parent { ann, left, right } => {
                let ann_bytes = ann.as_ref().map(|h| ByteArray::from(h.to_bytes()));

                let left_ser = SerializableNode::try_from(left.as_ref()).map(Box::new)?;
                let right_ser = SerializableNode::try_from(right.as_ref()).map(Box::new)?;
                Ok(SerializableNode::Parent(ann_bytes, left_ser, right_ser))
            }
            Node::Leaf { value } => {
                let (h, flag) = value;

                let bytes = ByteArray::from(h.to_bytes());
                Ok(SerializableNode::Leaf(bytes, flag.bits()))
            }

            Node::Nil => Ok(SerializableNode::Nil),
        }
    }
}

impl<H> TryFrom<&SerializableNode> for Tree<Option<Arc<H>>, (H, RetentionFlags)>
where
    H: MerkleCodec + Clone,
{
    type Error = ErrorWithMsg;

    fn try_from(node: &SerializableNode) -> IError<Self> {
        match node {
            SerializableNode::Nil => Ok(Tree::empty()),

            SerializableNode::Leaf(bytes, flag) => {
                let h = H::from_bytes((*bytes).into())?;

                let rf = RetentionFlags::from_bits(*flag).ok_or(ErrorWithMsg {
                    code: Error::InvalidRequest,
                    msg: "Invalid node flag integer".to_string(),
                })?;

                Ok(Tree::leaf((h, rf)))
            }

            SerializableNode::Parent(ann, left, right) => {
                let ann_h = match ann {
                    Some(b) => Some(Arc::new(H::from_bytes((*b).into())?)),
                    None => None,
                };

                let left_tree = Tree::try_from(left.as_ref())?;
                let right_tree = Tree::try_from(right.as_ref())?;

                Ok(Tree::parent(ann_h, left_tree, right_tree))
            }
        }
    }
}
impl SerializableNode {
    pub fn to_sapling_prunable_tree(&self) -> IError<PrunableTree<SaplingNode>> {
        Tree::try_from(self)
    }

    pub fn to_orchard_prunable_tree(&self) -> IError<PrunableTree<MerkleHashOrchard>> {
        Tree::try_from(self)
    }
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23030))]
#[cbor(array)]
pub struct NodeAddress {
    #[n(0)]
    level: u8,
    #[n(1)]
    index: u64,
}
impl From<NodeAddress> for Address {
    fn from(addr: NodeAddress) -> Self {
        Address::from_parts(addr.level.into(), addr.index)
    }
}
impl From<Address> for NodeAddress {
    fn from(addr: Address) -> Self {
        Self {
            level: addr.level().into(),
            index: addr.index(),
        }
    }
}
impl NodeAddress {
    pub fn to_address(&self) -> Address {
        Address::from_parts(Level::new(self.level), self.index)
    }
}
#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23033))]
#[cbor(array)]
pub struct SerializableTreeShard {
    #[n(0)]
    pub index: u64,
    #[n(1)]
    pub shard: SerializableNode,
}
impl SerializableTreeShard {
    pub fn to_located_prunable_tree<H>(&self) -> IError<LocatedPrunableTree<H>>
    where
        H: MerkleCodec + Clone,
    {
        let root = Tree::try_from(&self.shard)?;

        Ok(LocatedPrunableTree::from_parts(
            Address::from_parts(SHARD_HEIGHT_LEVEL, self.index),
            root,
        )
        .map_err(|_| ErrorWithMsg {
            code: Error::InvalidRequest,
            msg: "failed to create prunable tree".to_string(),
        })?)
    }

    pub fn to_sapling_located_prunable_tree(&self) -> IError<LocatedPrunableTree<SaplingNode>> {
        self.to_located_prunable_tree()
    }

    pub fn to_orchard_located_prunable_tree(
        &self,
    ) -> IError<LocatedPrunableTree<MerkleHashOrchard>> {
        self.to_located_prunable_tree()
    }
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23026))]
#[cbor(array)]
pub struct SerializableTreeCheckpoint {
    #[n(0)]
    pub position: Option<u64>,
    #[n(1)]
    pub checkpoint_id: u32,
}
impl SerializableTreeCheckpoint {
    pub fn get_checkpoint(&self) -> Checkpoint {
        match self.position {
            Some(position) => Checkpoint::at_position(position.into()),
            None => Checkpoint::tree_empty(),
        }
    }
    pub fn dummy(position: Option<u64>, checkpoint_id: u32) -> Self {
        SerializableTreeCheckpoint {
            position,
            checkpoint_id,
        }
    }
}
#[derive(Clone, Debug, Encode, Decode)]
#[cbor(array)]
#[cbor(tag(23034))]
pub struct SerializableShardTree {
    #[n(0)]
    pub cap: SerializableNode,
    #[n(1)]
    pub shards: Vec<SerializableTreeShard>,
    #[n(2)]
    pub checkpoints: Vec<SerializableTreeCheckpoint>,
}
impl SerializableShardTree {
    pub fn to_sapling_shard_tree(
        &self,
    ) -> IError<ShardTree<SaplingShardStore, { NOTE_COMMITMENT_TREE_DEPTH }, SHARD_HEIGHT>> {
        let mut tree = ShardTree::new(MemoryShardStore::empty(), MAX_CHECKPOINTS);
        let cap = self.cap.to_sapling_prunable_tree()?;
        tree.store_mut().put_cap(cap).map_err(|e| ErrorWithMsg {
            code: Error::InvalidRequest,
            msg: e.to_string(),
        })?;
        let shards = self.shards.clone();
        for shard in shards {
            let to_c = shard.to_sapling_located_prunable_tree()?;
            tree.store_mut().put_shard(to_c).map_err(|e| ErrorWithMsg {
                code: Error::InvalidRequest,
                msg: e.to_string(),
            })?;
        }
        let checkpoints = self.checkpoints.clone();
        for checkpoint in checkpoints {
            tree.store_mut()
                .add_checkpoint(checkpoint.checkpoint_id, checkpoint.get_checkpoint())
                .map_err(|e| ErrorWithMsg {
                    code: Error::InvalidRequest,
                    msg: e.to_string(),
                })?;
        }

        Ok(tree)
    }

    pub fn to_orchard_shard_tree(
        &self,
    ) -> IError<ShardTree<OrchardShardStore, { NOTE_COMMITMENT_TREE_DEPTH }, SHARD_HEIGHT>> {
        let mut tree = ShardTree::new(MemoryShardStore::empty(), MAX_CHECKPOINTS);
        let cap = self.cap.to_orchard_prunable_tree()?;
        tree.store_mut().put_cap(cap).map_err(|e| ErrorWithMsg {
            code: Error::InvalidRequest,
            msg: e.to_string(),
        })?;
        let shards = self.shards.clone();
        for shard in shards {
            let to_c = shard.to_orchard_located_prunable_tree()?;
            tree.store_mut().put_shard(to_c).map_err(|e| ErrorWithMsg {
                code: Error::InvalidRequest,
                msg: e.to_string(),
            })?;
        }
        let checkpoints = self.checkpoints.clone();
        for checkpoint in checkpoints {
            tree.store_mut()
                .add_checkpoint(checkpoint.checkpoint_id, checkpoint.get_checkpoint())
                .map_err(|e| ErrorWithMsg {
                    code: Error::InvalidRequest,
                    msg: e.to_string(),
                })?;
        }

        Ok(tree)
    }
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23029))]
#[cbor(array)]
pub struct SerializableLocatedPrunableTree {
    #[n(0)]
    pub root: SerializableNode,
    #[n(1)]
    pub address: NodeAddress,
}

impl<H> TryFrom<&SerializableLocatedPrunableTree> for LocatedPrunableTree<H>
where
    H: MerkleCodec + Clone,
{
    type Error = ErrorWithMsg;

    fn try_from(value: &SerializableLocatedPrunableTree) -> IError<Self> {
        let root_tree: Tree<Option<Arc<H>>, (H, RetentionFlags)> = Tree::try_from(&value.root)?;
        let root_addr: Address = value.address.clone().into();
        Ok(
            LocatedTree::from_parts(root_addr, root_tree).map_err(|_| ErrorWithMsg {
                code: Error::InvalidRequest,
                msg: "Failed to create locatedTree".to_string(),
            })?,
        )
    }
}
impl<H> TryFrom<&LocatedPrunableTree<H>> for SerializableLocatedPrunableTree
where
    H: MerkleCodec + Clone,
{
    type Error = ErrorWithMsg;
    fn try_from(tree: &LocatedPrunableTree<H>) -> Result<Self, Self::Error> {
        let root = SerializableNode::try_from(tree.root())?;

        let address = NodeAddress::from(tree.root_addr());

        Ok(SerializableLocatedPrunableTree { root, address })
    }
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23037))]
#[cbor(array)]
pub struct SerializableTreeCheckpointPosition {
    #[n(0)]
    pub checkpoint: u32,
    #[n(1)]
    pub position: u64,
}
#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23036))]
#[cbor(array)]
pub struct SerializableTreeInsertReport {
    #[n(0)]
    pub subtree: SerializableLocatedPrunableTree,
    #[n(1)]
    pub checkpoints: Vec<SerializableTreeCheckpointPosition>,
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23047))]
#[cbor(array)]
pub struct SubtreeRoots {
    #[n(0)]
    pub start: u32,
    #[n(1)]
    pub hashes: Vec<ByteArray<32>>,
}
impl SubtreeRoots {
    pub fn to_sapling_subtree_hashes(&self) -> IError<Vec<SaplingNode>> {
        self.hashes
            .iter()
            .map(|bytes| bytes.try_into_node())
            .collect()
    }
    pub fn to_orchard_subtree_hashes(&self) -> IError<Vec<MerkleHashOrchard>> {
        self.hashes
            .iter()
            .map(|bytes| bytes.try_into_merkle_hash())
            .collect()
    }
}
#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23039))]
#[cbor(array)]
pub struct SerializableNonEmptyFrontier {
    #[n(0)]
    pub position: u64,
    #[n(1)]
    pub leaf: ByteArray<32>,
    #[n(2)]
    pub ommers: Vec<ByteArray<32>>,
}
impl SerializableNonEmptyFrontier {
    pub fn to_sapling_non_empty_frontier(&self) -> IError<NonEmptyFrontier<SaplingNode>> {
        let ommers: Vec<_> = self
            .ommers
            .iter()
            .map(|bytes| bytes.try_into_node())
            .collect::<IError<Vec<_>>>()?;
        let leaf = self.leaf.try_into_node()?;
        let position: Position = self.position.into();
        NonEmptyFrontier::from_parts(position, leaf, ommers).map_err(|_| ErrorWithMsg {
            code: Error::InvalidRequest,
            msg: "Failed to initialize frontier".to_string(),
        })
    }
    pub fn to_orchard_non_empty_frontier(&self) -> IError<NonEmptyFrontier<MerkleHashOrchard>> {
        let ommers: Vec<_> = self
            .ommers
            .iter()
            .map(|bytes| bytes.try_into_merkle_hash())
            .collect::<IError<Vec<_>>>()?;
        let leaf = self.leaf.try_into_merkle_hash()?;
        let position: Position = self.position.into();
        NonEmptyFrontier::from_parts(position, leaf, ommers).map_err(|_| ErrorWithMsg {
            code: Error::InvalidRequest,
            msg: "Failed to initialize frontier".to_string(),
        })
    }
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23041))]
#[cbor(array)]
pub struct ChainState {
    #[n(0)]
    pub final_orchard_tree: Option<SerializableNonEmptyFrontier>,
    #[n(1)]
    pub final_sapling_tree: Option<SerializableNonEmptyFrontier>,
    #[n(2)]
    pub block_height: u32,
    #[n(3)]
    pub block_hash: ByteArray<32>,
}
#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23038))]
#[cbor(array)]
pub struct SerializableMerkleInsertReport {
    #[n(0)]
    pub orchard: Option<SerializableTreeInsertReport>,
    #[n(1)]
    pub sapling: Option<SerializableTreeInsertReport>,
    #[n(2)]
    pub height: u32,
    #[n(3)]
    pub final_orchard_tree: u32,
    #[n(4)]
    pub final_sapling_tree: u32,
    #[n(5)]
    pub chain_state: ChainState,
}
#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23048))]
#[cbor(array)]
pub struct BlockBundles {
    #[n(0)]
    pub sapling: ScannedProtocolBundles,
    #[n(1)]
    pub orchard: ScannedProtocolBundles,
}
#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23055))]
#[cbor(array)]
pub struct BlocksBundles {
    #[n(0)]
    pub bundles: Vec<BlockBundles>,
    #[n(1)]
    pub start_height: u32,
}
pub trait MerkleCodec: Sized {
    fn to_bytes(&self) -> [u8; 32];
    fn from_bytes(bytes: [u8; 32]) -> IError<Self>;
    fn encode(&self) -> ByteArray<32> {
        ByteArray::from(self.to_bytes())
    }
}
impl MerkleCodec for SaplingNode {
    fn to_bytes(&self) -> [u8; 32] {
        self.to_bytes()
    }

    fn from_bytes(bytes: [u8; 32]) -> IError<Self> {
        SaplingNode::from_bytes(bytes).map_err(|_| ErrorWithMsg {
            code: Error::InvalidRequest,
            msg: "Invalid sapling node bytes.".to_string(),
        })
    }
}
impl MerkleCodec for MerkleHashOrchard {
    fn to_bytes(&self) -> [u8; 32] {
        self.to_bytes()
    }

    fn from_bytes(bytes: [u8; 32]) -> IError<Self> {
        MerkleHashOrchard::from_bytes(&bytes)
            .into_option()
            .ok_or(ErrorWithMsg {
                code: Error::InvalidRequest,
                msg: "Invalid merkle hash orchard bytes.".to_string(),
            })
    }
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23035))]
#[cbor(array)]
pub struct ChainMerkleState {
    #[n(0)]
    pub sapling: SerializableShardTree,
    #[n(1)]
    pub orchard: SerializableShardTree,
    #[n(2)]
    pub sapling_subtree_index: u32,
    #[n(3)]
    pub orchard_sub_tree_index: u32,
}

#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23035))]
#[cbor(array)]
pub struct MerkleRequest {
    #[n(0)]
    pub id: u8,
    #[n(1)]
    #[cbor(with = "minicbor::bytes")]
    pub payload: Vec<u8>,
}
#[derive(Clone, Debug, Encode, Decode)]
#[cbor(tag(23035))]
#[cbor(array)]
pub struct MerkleContextRequest {
    #[n(0)]
    pub id: u32,
    #[n(1)]
    #[cbor(with = "minicbor::bytes")]
    pub payload: Vec<u8>,
}
