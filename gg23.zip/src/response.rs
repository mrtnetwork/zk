use std::string;

use crate::merkle::types::{ChainMerkleState, SerializableMerkleInsertReport};

#[derive(Debug, minicbor::Encode, minicbor::Decode)]
#[cbor(tag(23056))]
#[cbor(array)]
pub enum ZKResponse {
    #[n(0)]
    Error(#[n(0)] u32, #[n(1)] string::String),
    #[n(1)]
    Ok(),
    #[n(2)]
    SaplingHasParams(#[n(0)] bool),
    #[n(3)]
    SaplingProof(
        #[n(0)]
        #[cbor(with = "minicbor::bytes")]
        [u8; 192],
    ),
    #[n(4)]
    VerifyProof(#[n(0)] bool),
    #[n(5)]
    OrchardActionProof(
        #[n(0)]
        #[cbor(with = "minicbor::bytes")]
        Vec<u8>,
    ),
    #[n(6)]
    Version(#[n(0)] u8),

    #[n(7)]
    MerkleCreateContext(#[n(0)] u32),

    #[n(8)]
    MerkleUpdateResult(#[n(0)] SerializableMerkleInsertReport),
    #[n(9)]
    MerkleUpdateSubtreeResult(#[n(0)] u32),
    #[n(10)]
    MerkleGetContextResult(#[n(0)] ChainMerkleState),
}
