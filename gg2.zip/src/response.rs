use std::string;

#[derive(Debug, minicbor::Encode, minicbor::Decode)]
#[cbor(tag(23035))]
#[cbor(array)]
pub enum ZKResponse {
    #[n(0)]
    Error(#[n(0)] u32, #[n(1)] string::String),
    #[n(1)]
    Ok(),
    #[n(2)]
    SaplingHasParams(#[n(0)] bool),
    #[n(3)]
    SaplingSpendProof(
        #[n(0)]
        #[cbor(with = "minicbor::bytes")]
        [u8; 192],
    ),
    #[n(4)]
    SaplingOutputProof(
        #[n(0)]
        #[cbor(with = "minicbor::bytes")]
        [u8; 192],
    ),
    #[n(5)]
    VerifyProof(#[n(0)] bool),
    #[n(6)]
    OrchardActionProof(
        #[n(0)]
        #[cbor(with = "minicbor::bytes")]
        Vec<u8>,
    ),
}
