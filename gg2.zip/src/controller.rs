use crate::error::{Error, ErrorWithMsg, IError};
use crate::orchard::types::{OrchardProofParams, OrchardVerifyProofParams};
use crate::orchard::utils::{ProvingKey, ZKOrchardUtils};
use crate::request::ZKRequest;
use crate::response::ZKResponse;
use crate::sapling::circuit::{OutputParameters, SpendParameters};
use crate::sapling::prover::{OutputProver, SpendProver};
use crate::sapling::types::{
    SaplingOutputBytes, SaplingOutputVerificationBytes, SaplingSpendBytes,
    SaplingSpendVerificationBytes,
};
use crate::sapling::utils::ZKSaplingUtils;
use crate::sapling::{SaplingOutputProver, SaplingSpendProver};
use crate::{map::MyMap, merkle::context::MerkleContext};
use once_cell::sync::Lazy;
use rand_core::OsRng;
use std::io::Cursor;
use std::sync::Arc;
use std::sync::{atomic::AtomicU32, Mutex, RwLock};
pub static ZKCONTROLLER: Lazy<ZKController> = Lazy::new(|| ZKController::new());
pub struct ZKController {
    context: Mutex<MyMap<u32, MerkleContext>>,
    next_id: AtomicU32,

    spend_params: RwLock<Option<Arc<SpendParameters>>>,
    output_params: RwLock<Option<Arc<OutputParameters>>>,
    orchard_pk: RwLock<Option<Arc<ProvingKey>>>,
}
impl ZKController {
    pub fn new() -> Self {
        ZKController {
            context: Mutex::new(MyMap::new()),
            next_id: AtomicU32::new(1),
            spend_params: RwLock::new(None),
            output_params: RwLock::new(None),
            orchard_pk: RwLock::new(None),
        }
    }
    pub fn get_spend_params_inner(&self) -> IError<Arc<SpendParameters>> {
        let guard = self.spend_params.read().map_err(|e| ErrorWithMsg {
            code: Error::InternalError,
            msg: e.to_string(),
        })?;
        match &*guard {
            Some(p) => Ok(Arc::clone(p)),
            None => Err(ErrorWithMsg {
                code: Error::SaplingSpendNotInitialized,
                msg: "Spend parameters not initialized".to_string(),
            }),
        }
    }
    pub fn get_output_params_inner(&self) -> IError<Arc<OutputParameters>> {
        let guard = self.output_params.read().map_err(|e| ErrorWithMsg {
            code: Error::InternalError,
            msg: e.to_string(),
        })?;
        match &*guard {
            Some(p) => Ok(Arc::clone(p)),
            None => Err(ErrorWithMsg {
                code: Error::SaplingSpendNotInitialized,
                msg: "Spend parameters not initialized".to_string(),
            }),
        }
    }

    pub fn has_output_params_inner(&self) -> IError<bool> {
        let has_params = self
            .output_params
            .read()
            .map_err(|e| ErrorWithMsg {
                code: Error::InternalError,
                msg: e.to_string(),
            })?
            .is_some();
        Ok(has_params)
    }
    pub fn has_spend_params_inner(&self) -> IError<bool> {
        let has_params = self
            .spend_params
            .read()
            .map_err(|e| ErrorWithMsg {
                code: Error::InternalError,
                msg: e.to_string(),
            })?
            .is_some();
        Ok(has_params)
    }

    pub fn has_spend_params(&self) -> IError<ZKResponse> {
        self.has_spend_params_inner()
            .map(|has_params| ZKResponse::SaplingHasParams(has_params))
    }
    pub fn has_output_params(&self) -> IError<ZKResponse> {
        self.has_output_params_inner()
            .map(|has_params| ZKResponse::SaplingHasParams(has_params))
    }

    pub fn get_or_create_proving_key(&self) -> IError<Arc<ProvingKey>> {
        let mut guard = self.orchard_pk.write().map_err(|e| ErrorWithMsg {
            code: Error::InternalError,
            msg: e.to_string(),
        })?;

        if let Some(pk) = &*guard {
            return Ok(pk.clone());
        }

        let pk = Arc::new(ProvingKey::build());

        *guard = Some(pk.clone());

        Ok(pk)
    }
    pub fn setup_sapling_spend_params_inner(&self, payload: &[u8]) -> IError<ZKResponse> {
        self.has_spend_params_inner().and_then(|has_params| {
            if has_params {
                return Ok(ZKResponse::Ok());
            }
            let reader = Cursor::new(payload);
            let params = SpendParameters::read(reader, false).map_err(|e| ErrorWithMsg {
                code: Error::SaplingInvalidParameters,
                msg: e.to_string(),
            })?;
            *self.spend_params.write().map_err(|e| ErrorWithMsg {
                code: Error::InternalError,
                msg: e.to_string(),
            })? = Some(Arc::new(params));

            Ok(ZKResponse::Ok())
        })
    }
    pub fn setup_sapling_output_params_inner(&self, payload: &[u8]) -> IError<ZKResponse> {
        self.has_output_params_inner().and_then(|has_params| {
            if has_params {
                return Ok(ZKResponse::Ok());
            }
            let reader = Cursor::new(payload);
            let params = OutputParameters::read(reader, false).map_err(|e| ErrorWithMsg {
                code: Error::SaplingInvalidParameters,
                msg: e.to_string(),
            })?;
            *self.output_params.write().map_err(|e| ErrorWithMsg {
                code: Error::InternalError,
                msg: e.to_string(),
            })? = Some(Arc::new(params));

            Ok(ZKResponse::Ok())
        })
    }

    pub fn create_sapling_spend_proof(&self, params: SaplingSpendBytes) -> IError<ZKResponse> {
        let circuit = ZKSaplingUtils::parse_sapling_spend_proof(params)?;

        let spend_params = self.get_spend_params_inner()?; // Arc clone (cheap)
        let mut rng = OsRng;
        let prover = SaplingSpendProver { spend_params };

        let proof = prover.create_proof(circuit, &mut rng);

        let encoded = SaplingSpendProver::encode_proof(proof);

        Ok(ZKResponse::SaplingSpendProof(encoded))
    }
    pub fn verify_sapling_spend_proof(
        &self,
        params: SaplingSpendVerificationBytes,
    ) -> IError<ZKResponse> {
        let circuit = ZKSaplingUtils::parse_sapling_spend_verification(params)?;

        let spend_params = self.get_spend_params_inner()?; // Arc clone (cheap)
        let prover = SaplingSpendProver { spend_params };
        let proof = prover
            .parse_proof(circuit.proof)
            .map_err(|e| ErrorWithMsg {
                code: e,
                msg: "Invalid sapling proof bytes.".to_string(),
            })?;
        let verify = prover.verify(&proof, &circuit.public_inputs[..]);

        Ok(ZKResponse::VerifyProof(verify))
    }

    pub fn create_sapling_output_proof(&self, params: SaplingOutputBytes) -> IError<ZKResponse> {
        let circuit = ZKSaplingUtils::parse_sapling_output_proof(params)?;

        let output_params = self.get_output_params_inner()?; // Arc clone (cheap)
        let mut rng = OsRng;
        let prover = SaplingOutputProver { output_params };

        let proof = prover.create_proof(circuit, &mut rng);

        let encoded = SaplingSpendProver::encode_proof(proof);

        Ok(ZKResponse::SaplingOutputProof(encoded))
    }
    pub fn verify_sapling_output_proof(
        &self,
        params: SaplingOutputVerificationBytes,
    ) -> IError<ZKResponse> {
        let circuit = ZKSaplingUtils::parse_sapling_output_verification(params)?;
        let output_params = self.get_output_params_inner()?; // Arc clone (cheap)
        let prover = SaplingOutputProver { output_params };
        let proof = prover
            .parse_proof(circuit.proof)
            .map_err(|e| ErrorWithMsg {
                code: e,
                msg: "Invalid sapling proof bytes.".to_string(),
            })?;
        let verify = prover.verify(&proof, &circuit.public_inputs[..]);
        Ok(ZKResponse::VerifyProof(verify))
    }

    pub fn create_orchard_action_proof(&self, params: OrchardProofParams) -> IError<ZKResponse> {
        let key = self.get_or_create_proving_key()?;
        let proof = ZKOrchardUtils::create_orchard_proof(key, params)?;
        Ok(ZKResponse::OrchardActionProof(proof))
    }

    pub fn verify_orchard_action_proof(
        &self,
        params: OrchardVerifyProofParams,
    ) -> IError<ZKResponse> {
        let key = self.get_or_create_proving_key()?;
        let verify = ZKOrchardUtils::verify_orchard_proof(key, params)?;
        Ok(ZKResponse::VerifyProof(verify))
    }

    pub fn clear_sapling_spend_params(&self) -> IError<ZKResponse> {
        let mut guard = self.spend_params.write().map_err(|e| ErrorWithMsg {
            code: Error::InternalError,
            msg: e.to_string(),
        })?;

        *guard = None;

        Ok(ZKResponse::Ok())
    }

    pub fn clear_sapling_output_params(&self) -> IError<ZKResponse> {
        let mut guard = self.output_params.write().map_err(|e| ErrorWithMsg {
            code: Error::InternalError,
            msg: e.to_string(),
        })?;

        *guard = None;

        Ok(ZKResponse::Ok())
    }
    pub fn clear_orchard_proving_key(&self) -> IError<ZKResponse> {
        let mut guard = self.orchard_pk.write().map_err(|e| ErrorWithMsg {
            code: Error::InternalError,
            msg: e.to_string(),
        })?;

        *guard = None;

        Ok(ZKResponse::Ok())
    }
    pub fn parse_request(&self, payload: Vec<u8>) -> IError<ZKRequest> {
        minicbor::decode::<ZKRequest>(&payload).map_err(|e| ErrorWithMsg {
            code: Error::InvalidRequest,
            msg: e.to_string(),
        })
    }

    pub fn do_request_inner(&self, payload: Vec<u8>) -> IError<ZKResponse> {
        let request = self.parse_request(payload)?;
        match request {
            ZKRequest::MerkleCreateContext(chain_merkle_state) => todo!(),
            ZKRequest::MerkleUpdateSubtree(_, subtree_roots, subtree_roots1) => todo!(),
            ZKRequest::MerkleInsertChainState(_, chain_state) => todo!(),
            ZKRequest::MerkleUpdateState(_, blocks_bundles) => todo!(),
            ZKRequest::MerkleMergeState(_, serializable_merkle_insert_report) => todo!(),
            ZKRequest::MerkleCloseContext(_) => todo!(),
            ZKRequest::SaplingHasSpendParams() => self.has_spend_params(),
            ZKRequest::SaplingHasOutputParams() => self.has_output_params(),
            ZKRequest::SaplingSetupSpendParams(params) => {
                self.setup_sapling_spend_params_inner(&params)
            }
            ZKRequest::SaplingSetupOutputParams(params) => {
                self.setup_sapling_output_params_inner(&params)
            }
            ZKRequest::SaplingCreateSpendProof(params) => self.create_sapling_spend_proof(params),
            ZKRequest::SaplingCreateOutputProof(params) => self.create_sapling_output_proof(params),
            ZKRequest::SaplingVerifySpendProof(params) => self.verify_sapling_spend_proof(params),
            ZKRequest::SaplingVerifyOutputProof(params) => self.verify_sapling_output_proof(params),
            ZKRequest::OrchardCreateActionProof(params) => self.create_orchard_action_proof(params),
            ZKRequest::OrchardVerifyActionProof(params) => self.verify_orchard_action_proof(params),
            ZKRequest::SaplingClearSpendParams() => self.clear_sapling_spend_params(),
            ZKRequest::SaplingClearOutputParams() => self.clear_sapling_output_params(),
            ZKRequest::SaplingClearOrchardProvingKey() => self.clear_orchard_proving_key(),
        }
    }

    pub fn do_request(&self, payload: Vec<u8>) -> Result<Vec<u8>, Error> {
        // Error::InternalError
        let result = self
            .do_request_inner(payload)
            .unwrap_or_else(|e| ZKResponse::Error(e.code as u32, e.msg));
        minicbor::to_vec(&result).map_err(|_| Error::InternalError)
    }

    // /// Get or initialize OutputParameters from payload
    // pub fn setup_sapling_output_params_inner(payload: &[u8]) -> IError<ZKResponse> {
    //     let reader = Cursor::new(payload);
    //     OutputParameters::read(reader, false).map_err(|_| Error::SaplingInvalidParameters)
    // }

    // pub fn create_merkle_context(&self, bytes: Vec<u8>) -> Result<MerkleResponse, MerkleError> {
    //     let context = MerkleContext::deserialize(bytes)?;
    //     let id = self.next_id.fetch_add(1, Ordering::Relaxed);

    //     {
    //         let map = self.context.lock().unwrap();
    //         map.insert(id, context);
    //     }
    //     Ok(MerkleResponse::ContextCreated(id))
    // }

    // pub fn update_subtree(&self, bytes: Vec<u8>) -> Result<MerkleResponse, MerkleError> {
    //     let context = MerkleContext::deserialize(bytes)?;
    //     let id = self.next_id.fetch_add(1, Ordering::Relaxed);

    //     {
    //         let map = self.context.lock().unwrap();
    //         map.insert(id, context);
    //     }
    //     Ok(MerkleResponse::ContextCreated(id))
    // }
}
