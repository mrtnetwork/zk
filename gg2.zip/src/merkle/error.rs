#[repr(u32)]
pub enum MerkleError {
    Ok = 0,
    BadBundles = 1,
    InvalidEncoding = 2,
    InvalidRequest = 3,
}
