// use minicbor::{Decode, Encode};

// use crate::merkle::types::{
//     BlocksBundles, ChainMerkleState, ChainState, SerializableMerkleInsertReport, SubtreeRoots,
// };

// #[derive(Debug, Encode, Decode)]
// #[cbor(tag(23035))]
// #[cbor(array)]
// pub enum MerkleRequestKind {
//     #[n(0)]
//     MerkleCreateContext(#[n(0)] ChainMerkleState),
//     #[n(1)]
//     MerkleUpdateSubtree(#[n(0)] u32, #[n(1)] SubtreeRoots, #[n(2)] SubtreeRoots),
//     #[n(2)]
//     MerkleInsertChainState(#[n(0)] u32, #[n(1)] ChainState),
//     #[n(3)]
//     MerkleUpdateState(#[n(0)] u32, #[n(1)] BlocksBundles),
//     #[n(4)]
//     MerkleMergeState(#[n(0)] u32, #[n(1)] SerializableMerkleInsertReport),
//     #[n(5)]
//     MerkleCloseContext(#[n(0)] u32),
// }
