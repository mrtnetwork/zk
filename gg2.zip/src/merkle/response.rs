use minicbor::{Decode, Encode};

#[derive(Debug, minicbor::Encode, minicbor::Decode)]
#[cbor(tag(23035))]
#[cbor(array)]
pub enum MerkleResponse {
    #[n(1)]
    ContextCreated(#[n(0)] u32),
}
