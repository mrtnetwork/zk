use std::collections::HashMap;

#[cfg(not(target_arch = "wasm32"))]
use dashmap::DashMap;

#[cfg(target_arch = "wasm32")]
use std::sync::RwLock;

use std::sync::Mutex;

pub struct MyMap<K, V> {
    #[cfg(not(target_arch = "wasm32"))]
    inner: DashMap<K, V>,

    #[cfg(target_arch = "wasm32")]
    inner: RwLock<HashMap<K, V>>,
}
impl<K: Eq + std::hash::Hash, V> MyMap<K, V> {
    pub fn new() -> Self {
        Self {
            #[cfg(not(target_arch = "wasm32"))]
            inner: DashMap::new(),

            #[cfg(target_arch = "wasm32")]
            inner: RwLock::new(HashMap::new()),
        }
    }

    pub fn insert(&self, k: K, v: V) {
        #[cfg(not(target_arch = "wasm32"))]
        {
            self.inner.insert(k, v);
        }

        #[cfg(target_arch = "wasm32")]
        {
            self.inner.write().unwrap().insert(k, v);
        }
    }
}

// pub struct ShardedMap<K, V> {
//     shards: Vec<Mutex<MyMap<K, V>>>,
// }
